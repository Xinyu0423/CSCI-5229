# Hw1: Lorenz Attractor

## Author: Xinyu Jiang

## Instruction to Run
* Use `make` command to compile the code and run the hw1 file
* Use `make clean` command to clean the compiled program

## Instructions to Graders
* Type `1` to select parameter `s`
* Type `2` to select parameter `b`
* Type `3` to select parameter `r`

* Type `0` to reset to default `s`, `b` and `r` value.

* After parameters get selected, use `+` or `-` to edit the value of parameters `s`, `b` and `r` (It will increase by 2)

* Use arrows to change the view angle.
* Use esc to exit the program

## Time Spend
I spent about 6-7 hours on this assignment.

