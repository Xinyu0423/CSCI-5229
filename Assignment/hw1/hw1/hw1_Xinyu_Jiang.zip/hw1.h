//
//  hw1.h
//
//
//  Created by 蒋新宇 on 2021/6/5.
//

#ifndef hw1_h
#define hw1_h

#include <stdio.h>

#endif /* hw1_h */

